from ._version import __version__
from .predictor import LandmarkPredictor
